static const char screensaver_id[] =
	"@(#)xscreensaver 5.28 (04-Jun-2014), by Jamie Zawinski (jwz@jwz.org)";
